#librerías
import os
porcentaje_iva = 0.19

#FUNCIONES CARGAR ARCHIVOS
def cargar_archivo_servicios(ruta):
    catalogo_servicios = {}

    with open(ruta, "r") as archivo:
        archivo.readline()

        for linea in archivo:
            linea = linea.strip()
            if not linea:
                continue
            
            partes = linea.split(",")

            codigo_servicio = partes[0]
            descripcion = partes[1]
            costo_gasolina = int(partes[2])
            costo_diesel = int(partes[3])
            
            catalogo_servicios[codigo_servicio] = {
                "descripcion": descripcion,
                "gasolina": costo_gasolina,
                "diesel": costo_diesel
            }
    return catalogo_servicios

def cargar_archivo_repuestos(ruta):
    inventario_repuestos = {}

    with open(ruta, "r") as archivo:
        archivo.readline()

        for linea in archivo:
            linea = linea.strip()
            if not linea:
                continue
            
            partes = linea.split(",")

            codigo_servicio = partes[0]
            descripcion = partes[1]
            precio_unitario = int(partes[2])
            stock = int(partes[3])
            
            inventario_repuestos[codigo_servicio] = {
                "descripcion": descripcion,
                "precio_unitario": precio_unitario,
                "stock": stock
            }
    return inventario_repuestos

#FUNCIONES CREADAS PARA EL APARTADO NUMERO 1 UNOOOOOOOOOOOOOOOOOO

#Función creación de archivo orden cliente
def crear_orden (ruta: str):
    with open(ruta, "w") as archivo:
        pass

#Función Existencia de archivo en carpeta
def validar_existencia_orden (ruta : str):
    return os.path.exists(ruta)

#Función para escribir datos dentro de un archivo
def registrar_en_archivo (ruta : str, informacion : str):
    with open(ruta, "a") as archivo:
        archivo.write(informacion + "\n")

#VARIABLES CREADAS PARA EL APARTADO 2 DOOOSSSSS
"""
ruta_directorio = ""
"""

# FUNCIONES CREADAS PARA EL APARTADO 2 DOSSSSSSSSSSSSSSSS


try:
    #CARGAR ARCHIVOS
    ruta_servicios = "servicios.txt"
    catalogo_servicios = cargar_archivo_servicios(ruta_servicios)

    ruta_repuestos = "repuestos.csv"
    inventario_repuestos = cargar_archivo_repuestos(ruta_repuestos)

    ruta_directorio = "ordenes_abiertas/" 
    dict_combustible_carro = {} 

    opcion = ""

    while True:
            # IMPRIMIR MENÚ
            print(f"""
        {"="*40}
            FACTURACIÓN TALLER AUTOMOTRIZ
        {"="*40}
        MENÚ
        1. Ingresar Vehículo (Abrir Orden).
        2. Reportar Servicio en Orden.
        3. Cerrar orden (facturacion).
        4. Módulo de reportes (Análisis de datos).
        5. Salir
        """)
            # FIN MENÚ

            opcion = input("Seleccione una opción: ").strip()

            #=================================
            #APARTADO 1 : INGRESAR VEHÍCULO
            #=================================

            if opcion == "1":
                #PEDIR DATOS
                print("="*40)
                print(" INGRESAR VEHÍCULO")
                print("="*40)

                placa = input("Ingrese la placa del vehículo: ").strip().upper()
                marca = input("Ingrese la marca del vehículo: ").strip()
                tipo = input("Ingrese el tipo de vehículo: ").strip()
                combustible = input("Ingrese tipo de combustible (diesel o gasolina): ").strip()
                id_dueño = input("Ingrese el ID del dueño: ").strip()

                #CREAR RUTA DE ORDEN ARCHIVO
                ruta_orden = f"ordenes_abiertas/{placa}.txt"

                #VALIDAR EXISTENCIA DE LA ORDEN
                orden_repetida = validar_existencia_orden(ruta = ruta_orden)
                if orden_repetida:
                    print("\nERROR\nYa existe una orden con la misma placa...")
                    continue
                else:
                    #CREAR ORDEN
                    crear_orden(ruta = ruta_orden)

                    #INFORMACIÓN A AÑADIR EN LA ORDEN
                    datos_titular = (f"""
Placa: {placa}
Marca: {marca}
Tipo: {tipo}
Combustible: {combustible}
id_duenio: {id_dueño}
""").strip()
                    #DICCIONARIO CON LOS TIPOS DE COMBUSTIBLE DE CADA PLACA

                    dict_combustible_carro [placa] = combustible.lower().strip()

                    #REGISTRAR LOS DATOS DE EL DUEÑO DE LA ORDEN 
                    registrar_en_archivo(ruta_orden, datos_titular)
                    print("ORDEN CREADA CON ÉXITO.")


            
            #==========================================
            #APARTADO 2 : REPORTAR SERVICIO EN ORDEN
            #==========================================
            elif opcion == "2":
                lista_ordenes = []
                ordenes = ""
                placa_buscar = ""
                ruta = ""
                tipo_combustible = ""
                clave = ""
                datos_servicio = {}
                servicio_buscar = ""
                descripcion_servicio = ""
                costo_combustible = 0
                lista_repuestos_usados = []
                desea_repuesto = ""
                codigo_repuesto_buscar = ""
                cantidad_repuesto_buscar = 0
                stock_disponible = 0
                precio_unitario_repuesto = 0
                precio_repuesto_total = 0
                registro_repuesto = ""
                str_repuestos = ""
                linea_servicio = ""

                print("\nPLACAS REGISTRADAS EN ORDENES ABIERTAS:")
                lista_ordenes = os.listdir(ruta_directorio)

                for ordenes in lista_ordenes:
                    if ordenes.endswith(".txt"):
                        print(f"- {ordenes.replace('.txt', '')}")

                placa_buscar = input("\nIngrese la placa a reportar en servicio: ").upper().strip()
                ruta = f"ordenes_abiertas/{placa_buscar}.txt"
                
                if not validar_existencia_orden(ruta):
                    print("[ERROR]: Esta placa no existe en ordenes abiertas...")
                    continue

                tipo_combustible = dict_combustible_carro[placa_buscar]

                # SERVICIO A SELECCIONAR
                print("\nLista de servicios disponibles:")
                for clave, datos_servicio in catalogo_servicios.items():
                    print(f"Código: {clave} | {datos_servicio['descripcion']}")

                servicio_buscar = input("\nIngrese un código de servicio: ").upper().strip()
                if servicio_buscar not in catalogo_servicios:
                    print("[ERROR]: Código de servicio inválido.")
                    continue

                # COSTO SEGÚN TIPO DE COMBUSTIBLE
                descripcion_servicio = catalogo_servicios[servicio_buscar]["descripcion"]
                costo_combustible = catalogo_servicios[servicio_buscar][tipo_combustible]
                
                # MANEJO DE REPUESTOS
                lista_repuestos_usados = []

                while True:
                    desea_repuesto = input("\n¿Desea agregar un repuesto a este servicio? (s/n): ").strip().lower()
                    if desea_repuesto != "s":
                        break  

                    codigo_repuesto_buscar = input("Ingrese el código del repuesto: ").strip().upper()
                    
                    #Validar existencia ANTES de pedir cantidades
                    if codigo_repuesto_buscar not in inventario_repuestos:
                        print(f"[ERROR]: El código '{codigo_repuesto_buscar}' no existe en el inventario.")
                        continue

                    cantidad_repuesto_buscar = int(input(f"Ingrese la cantidad solicitada de [{inventario_repuestos[codigo_repuesto_buscar]['descripcion']}]: "))
                    if cantidad_repuesto_buscar <= 0:
                        print("[ERROR]: La cantidad debe ser mayor a cero.")
                        continue
                    
                    #Validación estricta de Stock físico en RAM
                    stock_disponible = inventario_repuestos[codigo_repuesto_buscar]["stock"]
                    if cantidad_repuesto_buscar > stock_disponible:
                        print(f"[ERROR]: Stock insuficiente. Solo quedan {stock_disponible} unidades.")
                        continue

                    inventario_repuestos[codigo_repuesto_buscar]["stock"] -= cantidad_repuesto_buscar

                    # Cálculos financieros individuales
                    precio_unitario_repuesto = inventario_repuestos[codigo_repuesto_buscar]["precio_unitario"]
                    precio_repuesto_total = cantidad_repuesto_buscar * precio_unitario_repuesto

                    # Empaquetar datos del repuesto (codigo:cantidad:total)
                    registro_repuesto = f"{codigo_repuesto_buscar}:{cantidad_repuesto_buscar}:{precio_repuesto_total}"
                    lista_repuestos_usados.append(registro_repuesto)
                    print(f"[OK]: Repuesto agregado con éxito.")

                # =======================================================
                # PERSISTENCIA: ESCRITURA EN EL ARCHIVO DE LA ORDEN
                # =======================================================
                # Unir los repuestos con punto y coma si existen
                str_repuestos = ";".join(lista_repuestos_usados) if lista_repuestos_usados else "Sin_Repuestos"
                
                # Armar la línea estructurada según requerimiento técnico:
                # codigo_servicio,descripcion_servicio,costo_mano_obra,[lista_repuestos]
                linea_servicio = f"{servicio_buscar},{descripcion_servicio},{costo_combustible},[{str_repuestos}]"
                
                # Escribir de forma persistente (append)
                registrar_en_archivo(ruta, linea_servicio)
                print(f"\n[ÉXITO]: Servicio {servicio_buscar} registrado correctamente en la orden {placa_buscar}.")
                

            #====================================
            #   APARTADO 3: CERRAR ORDEN
            #====================================
            elif opcion == "3":
                lista_archivos_ordenes = []
                nombre_archivo_orden = ""
                placa_para_cerrar = ""
                ruta_archivo_origen = ""
                fecha_emision_factura = ""
                suma_subtotal_mano_obra = 0
                suma_subtotal_repuestos = 0
                texto_acumulado_detalles_servicios = ""
                lineas_totales_archivo = []
                lineas_exclusivas_servicios = []
                texto_datos_vehiculo = ""
                linea_individual = ""
                linea_servicio = ""
                partes_servicio_separadas = []
                codigo_servicio_extraido = ""
                descripcion_servicio_extraida = ""
                costo_mano_obra_extraido = 0
                texto_repuestos_sin_procesar = ""
                texto_repuestos_limpio = ""
                lista_repuestos_individuales = []
                datos_repuesto_unido = ""
                partes_repuesto_separadas = []
                codigo_repuesto_extraido = ""
                cantidad_repuesto_extraida = 0
                costo_total_repuesto_extraido = 0
                nombre_repuesto_encontrado = ""
                subtotal_neto_general = 0
                valor_impuesto_iva = 0
                gran_total_factura = 0
                ruta_archivo_factura = ""
                ruta_archivo_destino = ""
                linea_guardar = ""
                codigo_repuesto_iterado = ""
                datos_repuesto_iterado = {}
                linea_csv_formateada = ""

                print("\n" + "="*40)
                print(" CERRAR ORDEN (FACTURACIÓN)")
                print("="*40)
                
                print("PLACAS DISPONIBLES PARA FACTURAR:")
                lista_archivos_ordenes = os.listdir(ruta_directorio)
                
                for nombre_archivo_orden in lista_archivos_ordenes:
                    if nombre_archivo_orden.endswith(".txt"):
                        print(f"- {nombre_archivo_orden.replace('.txt', '')}")
                
                placa_para_cerrar = input("\nIngrese la placa de la orden a cerrar: ").upper().strip()
                ruta_archivo_origen = f"ordenes_abiertas/{placa_para_cerrar}.txt"
                
                if not validar_existencia_orden(ruta_archivo_origen):
                    print("[ERROR]: El archivo de la orden no existe.")
                    continue

                fecha_emision_factura = input("Ingrese la fecha de hoy (AAAA-MM-DD): ").strip()

                # Acumuladores financieros y de texto descriptivo
                suma_subtotal_mano_obra = 0
                suma_subtotal_repuestos = 0
                texto_acumulado_detalles_servicios = ""

                # Leer el archivo de la orden abierta
                with open(ruta_archivo_origen, "r") as archivo_orden_abierta:
                    lineas_totales_archivo = archivo_orden_abierta.readlines()

                if len(lineas_totales_archivo) == 0:
                    print("[ERROR]: El archivo de la orden está vacío.")
                    continue

                for linea_individual in lineas_totales_archivo:
                    linea_individual = linea_individual.strip()
                    if not linea_individual:
                        continue
                    # Si la línea contiene una coma, es un servicio técnico reportado
                    if "," in linea_individual:
                        lineas_exclusivas_servicios.append(linea_individual)
                    else:
                        texto_datos_vehiculo = texto_datos_vehiculo + linea_individual + "\n"

                # Procesar cada servicio técnico encontrado
                for linea_servicio in lineas_exclusivas_servicios:
                    partes_servicio_separadas = linea_servicio.split(",")
                    
                    codigo_servicio_extraido = partes_servicio_separadas[0]
                    descripcion_servicio_extraida = partes_servicio_separadas[1]
                    costo_mano_obra_extraido = int(partes_servicio_separadas[2])
                    texto_repuestos_sin_procesar = partes_servicio_separadas[3] # Ej: "[R01:2:50000]"
                    
                    suma_subtotal_mano_obra = suma_subtotal_mano_obra + costo_mano_obra_extraido
                    texto_acumulado_detalles_servicios = texto_acumulado_detalles_servicios + f"Servicio: {codigo_servicio_extraido} - {descripcion_servicio_extraida} | Mano de Obra: ${costo_mano_obra_extraido}\n"
                    
                    # Limpiar los corchetes del texto de repuestos
                    texto_repuestos_limpio = texto_repuestos_sin_procesar.replace("[", "").replace("]", "")
                    
                    if texto_repuestos_limpio != "Sin_Repuestos" and texto_repuestos_limpio != "":
                        lista_repuestos_individuales = texto_repuestos_limpio.split(";")
                        for datos_repuesto_unido in lista_repuestos_individuales:
                            partes_repuesto_separadas = datos_repuesto_unido.split(":")
                            
                            codigo_repuesto_extraido = partes_repuesto_separadas[0]
                            cantidad_repuesto_extraida = int(partes_repuesto_separadas[1])
                            costo_total_repuesto_extraido = int(partes_repuesto_separadas[2])
                            
                            suma_subtotal_repuestos = suma_subtotal_repuestos + costo_total_repuesto_extraido
                            
                            # Buscar el nombre del repuesto en el diccionario de la RAM
                            nombre_repuesto_encontrado = inventario_repuestos[codigo_repuesto_extraido]["descripcion"]
                            texto_acumulado_detalles_servicios = texto_acumulado_detalles_servicios + f"   -> Repuesto: {codigo_repuesto_extraido} - {nombre_repuesto_encontrado} x{cantidad_repuesto_extraida} | Total: ${costo_total_repuesto_extraido}\n"

                # Cálculos de impuestos y totales generales
                subtotal_neto_general = suma_subtotal_mano_obra + suma_subtotal_repuestos
                valor_impuesto_iva = int(subtotal_neto_general * porcentaje_iva)
                gran_total_factura = subtotal_neto_general + valor_impuesto_iva

                # GENERAR ARCHIVO DE FACTURA FÍSICA
                ruta_archivo_factura = f"factura_{placa_para_cerrar}_{fecha_emision_factura}.txt"
                with open(ruta_archivo_factura, "w") as archivo_factura_final:
                    archivo_factura_final.write("="*50 + "\n")
                    archivo_factura_final.write("           FACTURA DE VENTA - TALLER\n")
                    archivo_factura_final.write(f"Fecha: {fecha_emision_factura}\n")
                    archivo_factura_final.write("="*50 + "\n")
                    archivo_factura_final.write("DATOS DEL VEHÍCULO:\n")
                    archivo_factura_final.write(texto_datos_vehiculo)
                    archivo_factura_final.write("-"*50 + "\n")
                    archivo_factura_final.write("DETALLE DEL TRABAJO:\n")
                    archivo_factura_final.write(texto_acumulado_detalles_servicios)
                    archivo_factura_final.write("-"*50 + "\n")
                    archivo_factura_final.write(f"Subtotal Mano de Obra: ${suma_subtotal_mano_obra}\n")
                    archivo_factura_final.write(f"Subtotal Repuestos:    ${suma_subtotal_repuestos}\n")
                    archivo_factura_final.write(f"Subtotal General:      ${subtotal_neto_general}\n")
                    archivo_factura_final.write(f"IVA (19%):             ${valor_impuesto_iva}\n")
                    archivo_factura_final.write(f"GRAN TOTAL A PAGAR:    ${gran_total_factura}\n")
                    archivo_factura_final.write("="*50 + "\n")

                print(f"\n[OK]: Factura '{ruta_archivo_factura}' generada exitosamente.")

                # MOVER ARCHIVO A ORDENES CERRADAS
                if not os.path.exists("ordenes_cerradas"):
                    os.makedirs("ordenes_cerradas")
                
                ruta_archivo_destino = f"ordenes_cerradas/{placa_para_cerrar}.txt"
                
                # Escribir copia en el directorio histórico
                with open(ruta_archivo_destino, "w") as archivo_destino_historico:
                    for linea_guardar in lineas_totales_archivo:
                        archivo_destino_historico.write(linea_guardar)
                
                # Eliminar del directorio activo
                os.remove(ruta_archivo_origen)
                
                # Sacar la placa del diccionario en RAM
                if placa_para_cerrar in dict_combustible_carro:
                    dict_combustible_carro.pop(placa_para_cerrar)
                
                print("[OK]: La orden fue trasladada a 'ordenes_cerradas'.")

                # SOBREESCRIBIR EL ARCHIVO REPUESTOS.CSV CON EL STOCK ACTUALIZADO
                with open(ruta_repuestos, "w") as archivo_inventario_csv:
                    archivo_inventario_csv.write("codigo_servicio,descripcion,precio_unitario,stock\n")
                    for codigo_repuesto_iterado, datos_repuesto_iterado in inventario_repuestos.items():
                        linea_csv_formateada = f"{codigo_repuesto_iterado},{datos_repuesto_iterado['descripcion']},{datos_repuesto_iterado['precio_unitario']},{datos_repuesto_iterado['stock']}\n"
                        archivo_inventario_csv.write(linea_csv_formateada)
                        
                print("[OK]: Base de datos de repuestos.csv guardada en disco.")

            #====================================
            #   APARTADO 4: MÓDULO DE REPORTES
            #====================================
            elif opcion == "4":
                opcion_sub_reporte = ""
                controlador_existe_stock_critico = False
                codigo_repuesto = ""
                informacion_repuesto = {}
                archivos_historicos_cerrados = []
                cantidad_ordenes_cerradas_procesadas = 0
                acumulado_total_mano_obra_historica = 0
                acumulado_total_repuestos_historicos = 0
                archivo_texto_cerrado = ""
                ruta_archivo_historial = ""
                lineas_archivo_historial = []
                linea_historial = ""
                partes_linea_historica = []
                costo_mano_obra_historico = 0
                bloque_repuestos_historico = ""
                lista_repuestos_historicos = []
                datos_repuesto_historico = ""
                partes_repuesto_historico = []
                subtotal_financiero_historico = 0
                iva_financiero_historico = 0
                gran_total_recaudado_historico = 0

                print("\n" + "="*40)
                print(" MÓDULO DE REPORTES Y ANÁLISIS")
                print("="*40)
                print("1. Reporte de Stock Crítico (Menos de 5 unidades)")
                print("2. Resumen financiero de Órdenes Cerradas")
                print("3. Volver al menú")
                
                opcion_sub_reporte = input("Seleccione tipo de reporte: ").strip()
                
                if opcion_sub_reporte == "1":
                    print("\n--- REPUESTOS CON STOCK CRÍTICO (< 5) ---")
                    for codigo_repuesto, informacion_repuesto in inventario_repuestos.items():
                        if informacion_repuesto["stock"] < 5:
                            print(f"Código: {codigo_repuesto} | {informacion_repuesto['descripcion']} | Quedan: {informacion_repuesto['stock']} unidades")
                            controlador_existe_stock_critico = True
                    if not controlador_existe_stock_critico:
                        print("No hay repuestos en estado crítico. Todo el stock es óptimo.")
                        
                elif opcion_sub_reporte == "2":
                    print("\n--- PROCESANDO HISTÓRICO DE ÓRDENES CERRADAS ---")
                    if not os.path.exists("ordenes_cerradas"):
                        print("No existe la carpeta de historial o no hay órdenes cerradas todavía.")
                        continue
                        
                    archivos_historicos_cerrados = os.listdir("ordenes_cerradas")

                    for archivo_texto_cerrado in archivos_historicos_cerrados:
                        if archivo_texto_cerrado.endswith(".txt"):
                            cantidad_ordenes_cerradas_procesadas = cantidad_ordenes_cerradas_procesadas + 1
                            ruta_archivo_historial = f"ordenes_cerradas/{archivo_texto_cerrado}"
                            
                            with open(ruta_archivo_historial, "r") as archivo_lector_historial:
                                lineas_archivo_historial = archivo_lector_historial.readlines()
                                
                            for linea_historial in lineas_archivo_historial:
                                linea_historial = linea_historial.strip()
                                if "," in linea_historial:
                                    partes_linea_historica = linea_historial.split(",")
                                    costo_mano_obra_historico = int(partes_linea_historica[2])
                                    bloque_repuestos_historico = partes_linea_historica[3]
                                    
                                    acumulado_total_mano_obra_historica = acumulado_total_mano_obra_historica + costo_mano_obra_historico
                                    
                                    bloque_repuestos_historico = bloque_repuestos_historico.replace("[", "").replace("]", "")
                                    if bloque_repuestos_historico != "Sin_Repuestos" and bloque_repuestos_historico != "":
                                        lista_repuestos_historicos = bloque_repuestos_historico.split(";")
                                        for datos_repuesto_historico in lista_repuestos_historicos:
                                            partes_repuesto_historico = datos_repuesto_historico.split(":")
                                            if len(partes_repuesto_historico) == 3:
                                                acumulado_total_repuestos_historicos = acumulado_total_repuestos_historicos + int(partes_repuesto_historico[2])
                    
                    subtotal_financiero_historico = acumulado_total_mano_obra_historica + acumulado_total_repuestos_historicos
                    iva_financiero_historico = int(subtotal_financiero_historico * porcentaje_iva)
                    gran_total_recaudado_historico = subtotal_financiero_historico + iva_financiero_historico
                    
                    print(f"Cantidad de órdenes cerradas evaluadas: {cantidad_ordenes_cerradas_procesadas}")
                    print(f"Total recaudado por Mano de Obra:       ${acumulado_total_mano_obra_historica}")
                    print(f"Total recaudado por Repuestos:          ${acumulado_total_repuestos_historicos}")
                    print(f"Total IVA recaudado histórico:          ${iva_financiero_historico}")
                    print(f"Gran Total Facturado Histórico:         ${gran_total_recaudado_historico}")
                    
                elif opcion_sub_reporte == "3":
                    continue


            elif opcion == "5":
                print("Saliendo del sistema...")
                break
            else:
                print("OPCIÓN INVÁLIDA. Intente de nuevo.")
                pass
except Exception as e:
    print(e)